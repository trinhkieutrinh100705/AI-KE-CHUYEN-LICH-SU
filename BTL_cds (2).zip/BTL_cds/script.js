// Dữ liệu câu chuyện đã được định nghĩa sẵn
const story = [
    {
        text: "Năm ấy, đất trời phương Nam đang bước vào một mùa đông xám lạnh. Dòng sông Bạch Đằng mênh mang, rộng lớn, vẫn chảy ra biển như bao đời nay, nhưng ẩn sâu trong lòng nước, những cơn sóng ngầm đang dấy lên. Tin dữ truyền khắp nơi: Kiều Công Tiễn, kẻ từng được Dương Đình Nghệ tin dùng, nay phản bội, giết chủ để đoạt quyền cai quản Tĩnh Hải quân. Không dừng lại ở đó, hắn còn lén gửi thư sang phương Bắc, cầu cứu nhà Nam Hán – kẻ đang nuôi mộng xâm lược, mong đưa quân sang giúp hắn giữ ngôi.",
        image: "assets/images/hinh1.png",
        audio: "assets/audio/doan1.mp3"
    },
    {
        text: "Ở Ái Châu xa xôi, Ngô Quyền – con rể Dương Đình Nghệ – nhận tin mà lòng như lửa đốt. Ông là bậc anh hùng dạn dày trận mạc, từng theo cha vợ đánh đuổi quân xâm lăng, hiểu rõ giá trị của độc lập. Ngay lập tức, ông tập hợp quân sĩ, lên đường tiến ra Bắc với quyết tâm diệt kẻ phản bội trước khi viện binh phương Bắc kịp tới. Chỉ ít ngày sau, thành Đại La rơi vào tay Ngô Quyền, Kiều Công Tiễn đền tội. Nhưng chiến thắng ấy chưa kịp làm vơi bớt mối lo, bởi ngoài khơi xa, bóng cờ Nam Hán đã thấp thoáng trên mặt biển.",
        image: "assets/images/hinh2.png",
        audio: "assets/audio/doan2.mp3"
    },
    {
        text: "Nhưng chiến thắng ấy chưa kịp làm vơi bớt mối lo, bởi ngoài khơi xa, bóng cờ Nam Hán đã thấp thoáng trên mặt biển. Vua Nam Hán Lưu Cung vốn chờ cơ hội thôn tính đất Việt từ lâu. Nhận được thư cầu cứu, y lập tức sai con trai là Lưu Hoằng Tháo chỉ huy một hạm đội hùng hậu, theo đường biển tiến vào sông Bạch Đằng, còn y thân chinh đem quân đóng ở biên giới để tiếp ứng.",
        image: "assets/images/hinh3.png",
        audio: "assets/audio/doan3.mp3"
    },
    {
        text: "Đối đầu với thế lực mạnh hơn, Ngô Quyền không hề nao núng. Ông hiểu rằng, để thắng được kẻ địch thiện chiến và đông đảo, phải dựa vào mưu trí và địa thế. Sông Bạch Đằng, con sông lớn thông ra biển, có cửa sông rộng nhưng đáy lại lắm bãi cạn, chịu ảnh hưởng mạnh của thủy triều. Nước lên nhanh, rút cũng nhanh, để lộ những dải bùn lầy và đá ngầm hiểm trở.",
        image: "assets/images/hinh4.png",
        audio: "assets/audio/doan4.mp3"
    },
    {
        text: "Ngô Quyền quyết định biến nơi này thành bãi mồ chôn quân xâm lược. Ông ra lệnh đốn những cây gỗ lim, gỗ táu to lớn, vót nhọn, bịt sắt ở đầu, rồi cho quân cắm ngầm xuống đáy sông, mũi nhọn hướng ra phía biển. Hàng ngàn chiếc cọc như những thanh kiếm khổng lồ giấu mình dưới làn nước đục, chờ thời cơ trỗi dậy.",
        image: "assets/images/hinh5.png",
        audio: "assets/audio/doan5.mp3"
    },
    {
        text: "Kế hoạch đã định: khi thủy triều dâng, sẽ nhử thuyền địch tiến sâu vào vùng bãi cọc. Lúc ấy, nước ngập, cọc chìm, thuyền địch không hề hay biết. Khi thủy triều rút, những chiếc thuyền nặng nề sẽ mắc cạn, va vào đầu cọc mà thủng đáy, trở thành mồi ngon cho quân ta tiêu diệt.",
        image: "assets/images/hinh6.png",
        audio: "assets/audio/doan6.mp3"
    },
    {
        text: "Những ngày cuối năm 938, sóng biển Đông nổi trắng xóa. Hạm đội Nam Hán do Lưu Hoằng Tháo dẫn đầu rẽ sóng tiến vào cửa sông. Trên bờ, quân Ngô mai phục im lặng như những bóng đá ven rừng sú vẹt. Khi thủy triều dâng cao, Ngô Quyền cho một đội thuyền nhẹ tiến ra khiêu chiến. Tiếng trống trận vang rền, tiếng hò reo vọng lại từ vách núi, khiến quân địch càng thêm hăng máu. Chúng ào ạt đuổi theo, nghĩ rằng chỉ cần một trận là quét sạch quân Giao Châu.",
        image: "assets/images/hinh7.png",
        audio: "assets/audio/doan7.mp3"
    },
    {
        text: "Đoàn thuyền Nam Hán tiến sâu vào lòng sông, nơi những chiếc cọc gỗ đang nằm ẩn mình. Ngô Quyền giả vờ cho quân rút lui, kéo chúng đi xa hơn. Khi mũi thuyền cuối cùng của Nam Hán vừa lọt vào trận địa, ông ra hiệu cho quân mai phục sẵn sàng. Rồi, như có sự hòa hợp giữa con người và trời đất, thủy triều bắt đầu rút.",
        image: "assets/images/hinh8.png",
        audio: "assets/audio/doan8.mp3"
    },
    {
        text: "Ban đầu chỉ là những đợt sóng nhỏ rút nhẹ, rồi nước chảy xiết, dòng sông dần để lộ bộ mặt thật của nó. Những bãi cọc bắt đầu trồi lên, nhọn hoắt như răng cá sấu. Thuyền chiến Nam Hán, vốn to và nặng, giờ mắc kẹt vào bùn lầy, va phải cọc, đáy thuyền rách toạc, nước tràn vào ồng ộc. Tiếng binh lính la hét hòa với tiếng gỗ vỡ, tiếng sóng đánh dồn dập.",
        image: "assets/images/hinh9.png",
        audio: "assets/audio/doan9.mp3"
    },
    {
        text: "Đúng lúc đó, Ngô Quyền tung toàn bộ lực lượng. Từ hai bên bờ, hàng trăm thuyền nhỏ của quân ta lao ra như những mũi tên. Tên bắn như mưa, lao xuống boong thuyền địch. Gươm giáo sáng loáng, tiếng trống trận và tiếng hò reo làm rung chuyển cả một khúc sông. Quân Nam Hán hoảng loạn, người rơi xuống nước bị dòng chảy cuốn trôi, kẻ còn sống thì bị chém gục trên thuyền. Giữa cảnh hỗn loạn, Lưu Hoằng Tháo trúng tên tử trận, khiến toàn quân rệu rã, tan vỡ.",
        image: "assets/images/hinh10.png",
        audio: "assets/audio/doan10.mp3"
    },
    {
        text: "Khi mặt trời xuống thấp, sông Bạch Đằng chỉ còn lại những mảnh vỡ của thuyền chiến, những xác cọc nhô lên lẫn trong xác thù. Sóng nước hôm ấy đỏ màu máu, nhưng cũng hát vang khúc khải hoàn của dân tộc. Tin chiến thắng truyền về kinh đô, rồi bay sang tận đất Nam Hán. Lưu Cung nghe tin con chết, quân mất gần hết, đành đau đớn rút quân, từ bỏ mộng xâm lăng.",
        image: "assets/images/hinh11.png",
        audio: "assets/audio/doan11.mp3"
    },
    {
        text: "Chiến thắng Bạch Đằng năm 938 đã ghi dấu mốc chấm dứt hơn một nghìn năm Bắc thuộc, mở ra kỷ nguyên độc lập lâu dài cho dân tộc. Ngô Quyền, với tài thao lược xuất chúng, đã không chỉ đánh thắng một trận thủy chiến lẫy lừng mà còn để lại một bài học quân sự bất hủ: biết nắm thời cơ, lợi dụng địa hình, biến thiên nhiên thành vũ khí. Sau này, thế trận cọc Bạch Đằng lại được con cháu như Trần Hưng Đạo vận dụng, tiếp nối truyền thống đánh giặc giữ nước.",
        image: "assets/images/hinh12.png",
        audio: "assets/audio/doan12.mp3"
    },
    {
        text: "Từ đó, mỗi khi nhắc đến sông Bạch Đằng, người Việt lại nhớ đến buổi chiều đông năm 938 – khi sóng nước và mưu trí hòa làm một, khi tiếng trống trận của Ngô Quyền vọng khắp non sông, và khi đất nước chính thức bước sang trang sử độc lập, tự chủ, ngẩng cao đầu giữa trời Nam.",
        image: "assets/images/hinh13.png",
        audio: "assets/audio/doan13.mp3"
    },
    {
        text: "Cảm ơn mọi người đã chú ý lắng nghe!",
        image: "assets/images/hinh14.png", 
        audio: "assets/audio/doan14.mp3"
    }
];

let currentSceneIndex = -1; // -1: trạng thái ban đầu
let currentAudio = null;

const startButton = document.getElementById('start-button');
const prevButton = document.getElementById('prev-button');
const nextButton = document.getElementById('next-button');
const storyImage = document.getElementById('story-image');
const storyText = document.getElementById('story-text');
const storyTitleLink = document.getElementById('story-title-link');
const storyContent = document.getElementById('story-content');

// Hàm cập nhật trạng thái các nút
function updateButtons() {
    // Ẩn/hiện các nút điều hướng và nút bắt đầu
    if (currentSceneIndex === -1) {
        startButton.style.display = 'block';
        prevButton.style.display = 'none';
        nextButton.style.display = 'none';
    } else {
        startButton.style.display = 'none';
        prevButton.style.display = 'inline-block';
        nextButton.style.display = 'inline-block';
    }
    
    // Vô hiệu hóa nút "Quay lại" nếu ở trang đầu
    prevButton.disabled = currentSceneIndex <= 0;
    
    // Vô hiệu hóa nút "Tiếp theo" nếu ở trang cuối
    if (currentSceneIndex === story.length - 1) {
        nextButton.disabled = true;
        startButton.style.display = 'block';
        startButton.textContent = 'Bắt đầu lại';
    } else {
        nextButton.disabled = false;
        startButton.textContent = 'Bắt đầu';
    }
}

// Hàm hiển thị nội dung câu chuyện
function showScene(index) {
    if (currentAudio) {
        currentAudio.pause();
        currentAudio.currentTime = 0;
    }

    if (index >= 0 && index < story.length) {
        const scene = story[index];
        storyImage.src = scene.image;
        storyImage.style.display = 'block';
        storyText.textContent = scene.text;
        
        const audio = new Audio(scene.audio);
        audio.play().catch(e => console.error("Lỗi phát âm thanh:", e));
        currentAudio = audio;

        currentSceneIndex = index;
    } else {
        // Trạng thái ban đầu
        storyText.textContent = "Nhấn 'Bắt đầu' để khám phá câu chuyện.";
        storyImage.style.display = 'none';
        currentSceneIndex = -1;
    }
    updateButtons();
}

// Xử lý chuyển trang với hiệu ứng fade
function goToScene(index) {
    storyContent.classList.add('fade-out');
    
    setTimeout(() => {
        showScene(index);
        storyContent.classList.remove('fade-out');
        storyContent.classList.add('fade-in');
        
        setTimeout(() => {
            storyContent.classList.remove('fade-in');
        }, 500);
    }, 500);
}

// Thêm sự kiện click
startButton.addEventListener('click', () => {
    goToScene(0);
});

nextButton.addEventListener('click', () => {
    goToScene(currentSceneIndex + 1);
});

prevButton.addEventListener('click', () => {
    goToScene(currentSceneIndex - 1);
});

// Thêm sự kiện click cho tiêu đề để quay về trang đầu tiên
storyTitleLink.addEventListener('click', (event) => {
    event.preventDefault();
    if (currentAudio) {
        currentAudio.pause();
    }
    showScene(-1);
});

// Khởi tạo ban đầu
document.addEventListener('DOMContentLoaded', () => {
    showScene(-1);
});